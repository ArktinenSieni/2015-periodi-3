package thechase.logiikka.algoritmit;

import java.awt.Point;
import java.util.PriorityQueue;
import thechase.logiikka.Suunta;
import thechase.logiikka.asiat.Asia;
import thechase.logiikka.asiat.Hahmo;

/**
 * A*-toteutus. http://www.redblobgames.com/pathfinding/a-star/introduction.html
 * @author mcraty
 */
public class AStar implements Algoritmi{
    private Hahmo hahmo;
    private Asia kohde;
    private Solmu[][] kartta;
    private Asia pahis;
    
    public AStar(Hahmo hahmo, Asia kohde) {
        this.hahmo = hahmo;
        this.kohde = kohde;
        this.pahis = null;
    }
    
    public AStar(Hahmo hahmo, Asia kohde, Asia pahis) {
        this.hahmo = hahmo;
        this.kohde = kohde;
        this.pahis = pahis;
    }

    @Override
    public Suunta etene() {
        kartta = new Solmu[hahmo.kartanMitat().x + 1][hahmo.kartanMitat().y + 1];
        Solmu alku = uusiSolmu(hahmo.sijainti());
        alku.setKayty();
        
        Solmu reitti = ATahti(alku);
        Solmu viereinen = etsiReitistaViereinen(reitti, alku);
                
        return suunta(alku, viereinen);
    }
    
    /**
     * Etsii reitin hahmosta kohteeseen.
     * @param alku Hahmon sijainti
     * @return Solmu joka on kohteen sijainti.
     */
    public Solmu ATahti(Solmu alku) {
        Solmu nykyinen = null;
        
        PriorityQueue<Solmu> rajaseutu = new PriorityQueue<Solmu>();
        alku.setPrioriteetti(0);
        rajaseutu.add(alku);
        
        while (!rajaseutu.isEmpty()) {
            nykyinen = rajaseutu.poll();
            
            if (nykyinen.sijainti().x == kohde.sijainti().x 
                    && nykyinen.sijainti().y == kohde.sijainti().y) {
                break;
            }
            
            Solmu[] viereiset = viereiset(nykyinen);
            for (Solmu vierus : viereiset) {
                if (vierus == null) {
                    continue;
                }
                int uusiPaino = nykyinen.getPaino() + laskePaino(vierus, pahis);
                
                if (!vierus.getKayty() || uusiPaino < vierus.getPaino()) {
                    vierus.setKayty();
                    vierus.setPaino(uusiPaino);
                    vierus.setPrioriteetti(uusiPaino + heuristiikka(vierus, kohde));
                    rajaseutu.add(vierus);
                    vierus.setEdellinen(nykyinen);
                }
            }
        }
        
        return nykyinen;
    }
    /**
     * Luo solmuja. Jos solmu on jo olemassa, palautetaan olemassa oleva.
     * @param sijainti Halutun solmun sijainti.
     * @return Luotu tai haettu solmu.
     */
    private Solmu uusiSolmu(Point sijainti) {
        if (kartta[sijainti.x][sijainti.y] == null) {
            kartta[sijainti.x][sijainti.y] = new Solmu(sijainti.x, sijainti.y, 0);
        }
        return kartta[sijainti.x][sijainti.y];
    }
    
    /**
     * Hakee parametrisolmun ympärillä olevat vapaat solmut.
     * @param nykyinen halutun solmun viereiset.
     * @return lista viereisistä solmuista.
     */
    private Solmu[] viereiset(Solmu nykyinen) {
        Solmu[] viereiset = new Solmu[4];
        
        Point suunta = new Point(nykyinen.sijainti().x + Suunta.ALAS.x, nykyinen.sijainti().y + Suunta.ALAS.y);
        if (hahmo.onkoVapaa(suunta)) {
            viereiset[0] = uusiSolmu(suunta);
        }
        suunta = new Point(nykyinen.sijainti().x + Suunta.YLOS.x, nykyinen.sijainti().y + Suunta.YLOS.y);
        if (hahmo.onkoVapaa(suunta)) {
            viereiset[1] = uusiSolmu(suunta);
        }
        suunta = new Point(nykyinen.sijainti().x + Suunta.VASEN.x, nykyinen.sijainti().y + Suunta.VASEN.y);
        if (hahmo.onkoVapaa(suunta)) {
            viereiset[2] = uusiSolmu(suunta);
        }
        suunta = new Point(nykyinen.sijainti().x + Suunta.OIKEA.x, nykyinen.sijainti().y + Suunta.OIKEA.y);
        if (hahmo.onkoVapaa(suunta)) {
            viereiset[3] = uusiSolmu(suunta);
        }
        
        
        return viereiset;
    }
    
    /**
     * Laskee heuristiikan. Tässä käytän Manhattan-etäisyyttä.
     * @param seuraava Mistä lasketaan.
     * @param kohde Mihin lasketaan.
     * @return heuristiikan arvo.
     */
    private int heuristiikka(Solmu seuraava, Asia kohde) {
        return Math.abs(seuraava.sijainti().x - kohde.sijainti().x) 
                + Math.abs(seuraava.sijainti().y - kohde.sijainti().y);
    }
    
    /**
     * Alkeellinen painon asettaminen hirviön ympäristöön, jos se on asetettu. 
     * @param seuraava Minkä solmun painoa tarkastellaan.
     * @param pahis Mitä vältetään.
     * @return Paino.
     */
    private int laskePaino(Solmu seuraava, Asia pahis) {
        if (pahis != null) {
            int heuristiikka = heuristiikka(seuraava, pahis);
            if (heuristiikka == 0) return 10;
            else if (heuristiikka == 1) return 9;
            else if (heuristiikka == 2) return 8;
            else if (heuristiikka == 3) return 7;
            else if (heuristiikka == 4) return 6;
            else if (heuristiikka == 5) return 5;
            else if (heuristiikka == 6) return 4;
            else if (heuristiikka == 7) return 3;
            else if (heuristiikka == 8) return 2;
        }
        
        return 1;
    }
    
    /**
     * Kelaa löydetyn reitin viimeisestä solmusta alkusolmun viereiseen solmuun.
     * 
     * @param loppu Kohdesolmu.
     * @param alku Hahmon solmu.
     * @return Hahmon viereinen solmu.
     */
    private Solmu etsiReitistaViereinen(Solmu loppu, Solmu alku) {
        Solmu vierus = loppu;
        
        while(vierus.edellinen()!= alku) {
            vierus = vierus.edellinen();
        }
        
        return vierus;
    }
    
    /**
     * Antaa suunnan, missä viereinen solmu on.
     * @param alku Hahmo.
     * @param viereinen Hahmon vierussolmu.
     * @return Mentävä sunta.
     */
    private Suunta suunta(Solmu alku, Solmu viereinen) {
        int eroX = viereinen.sijainti().x - alku.sijainti().x;
        int eroY = viereinen.sijainti().y - alku.sijainti().y;
        
        if (eroX == 0 && eroY == -1) return Suunta.YLOS;
        else if (eroX == 0 && eroY == 1) return Suunta.ALAS;
        else if (eroX == 1 && eroY == 0) return Suunta.OIKEA;
        else if (eroX == -1 && eroY == 0) return Suunta.VASEN;
        return Suunta.ISTU;
    }
}
