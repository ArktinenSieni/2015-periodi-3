package thechase.logiikka.algoritmit;

import java.awt.Point;
import java.util.ArrayDeque;
import java.util.PriorityQueue;
import thechase.logiikka.Suunta;
import thechase.logiikka.asiat.Asia;
import thechase.logiikka.asiat.Hahmo;
import thechase.logiikka.asiat.Palkinto;

/**
 * Greedy-Best-Find algoritmi.
 * http://www.redblobgames.com/pathfinding/a-star/introduction.html 
 * Kevennetty leveyssuuntainen haku, joka priorisoi tutkittavia solmuja niiden
 * etäisyyden ja isäntäsolmun etäisyyden mukaan.
 *
 * @author mcraty
 */
public class GreedyBestFind implements Algoritmi {

    Hahmo hahmo;
    Asia kohde;
    boolean[][] onkoKayty;

    public GreedyBestFind(Hahmo hahmo, Asia kohde) {
        this.hahmo = hahmo;
        this.kohde = kohde;
        onkoKayty = new boolean[hahmo.kartanMitat().x + 1][hahmo.kartanMitat().y + 1];

    }
    
    /**
     * Palauttaa parhaan suuntavaihtoehdon, jonne algoritmin käyttäjän olisi tarkoitus liikkua.
     * @return Edettävä suunta.
     */
    @Override
    public Suunta etene() {
        onkoKayty = new boolean[hahmo.kartanMitat().x + 1][hahmo.kartanMitat().y + 1];
        PriorityQueue<Solmu> tutkittavat = new PriorityQueue<Solmu>();
        Solmu nykyinen = null;
        onkoKayty[hahmo.sijainti().x][hahmo.sijainti().y] = true;

        ArrayDeque<Point> viereiset = this.viereiset(hahmo.sijainti().x, hahmo.sijainti().y);
        while (!viereiset.isEmpty()) {
            Point v = viereiset.poll();
            tutkittavat.add(new Solmu(v.x, v.y, etaisyys(v.x, v.y, kohde)));
        }

        while (!tutkittavat.isEmpty()) {
            nykyinen = tutkittavat.poll();
            onkoKayty[nykyinen.sijainti().x][nykyinen.sijainti().y] = true;

            if (nykyinen.sijainti().x == kohde.sijainti().x 
		&& nykyinen.sijainti().y == kohde.sijainti().y) {
                break;
            }

            viereiset = this.viereiset(nykyinen.sijainti().x, nykyinen.sijainti().y);
            while (!viereiset.isEmpty()) {
                Point v = viereiset.poll();
                tutkittavat.add(new Solmu(v.x, v.y, etaisyys(v.x, v.y, kohde), nykyinen));
            }

        }
        
        while (nykyinen.edellinen() != null) {
            nykyinen = nykyinen.edellinen();
        }

        return suunnassa(nykyinen);
    }

    /**
     * Laskee Manhattan-etäisyyden annetuista koordinaateista koheeseen.
     * 
     * @param mistaX annettu x-koordinatti
     * @param mistaY annettu y-koordinaatti
     * @param kohde annettu kohde
     * @return Manhattanetäisyys
     */
    public int etaisyys(int mistaX, int mistaY, Asia kohde) {
        return Math.abs(mistaX - kohde.sijainti().x)
                + Math.abs(mistaY - kohde.sijainti().y);
    }

    /**
     * Palauttaa listan viereisistä vapaista ruuduista. Pahoittelen
     * copy-pastesta.
     *
     * @param x tarkasteltavan ruudun x-koordinaatti
     * @param y tarkasteltavan ruudun y-koordinaatti
     * @return tarkasteltavan ruudun ympärillä olevalt vapaat ruudut.
     */
    public ArrayDeque<Point> viereiset(int x, int y) {
        ArrayDeque<Point> viereiset = new ArrayDeque<Point>();

        //alas
        int minneX = x;
        int minneY = y + 1;

        if (minneX <= hahmo.kartanMitat().x && minneY <= hahmo.kartanMitat().y && minneX >= 0 && minneY >= 0) {
            if (hahmo.getKartta()[minneX][minneY] != null && !hahmo.getKartta()[minneX][minneY].ylitettava()) {

            } else if (!onkoKayty[minneX][minneY]) {
                viereiset.add(new Point(minneX, minneY));
            }
        }
        //ylös
        minneX = x;
        minneY = y - 1;

        if (minneX <= hahmo.kartanMitat().x && minneY <= hahmo.kartanMitat().y && minneX >= 0 && minneY >= 0) {
            if (hahmo.getKartta()[minneX][minneY] != null && !hahmo.getKartta()[minneX][minneY].ylitettava()) {

            } else if (!onkoKayty[minneX][minneY]) {
                viereiset.add(new Point(minneX, minneY));
            }
        }
        //vasemmalle
        minneX = x - 1;
        minneY = y;

        if (minneX <= hahmo.kartanMitat().x && minneY <= hahmo.kartanMitat().y && minneX >= 0 && minneY >= 0) {
            if (hahmo.getKartta()[minneX][minneY] != null && !hahmo.getKartta()[minneX][minneY].ylitettava()) {

            } else if (!onkoKayty[minneX][minneY]) {
                viereiset.add(new Point(minneX, minneY));
            }
        }
        //oikealle
        minneX = x + 1;
        minneY = y;

        if (minneX <= hahmo.kartanMitat().x && minneY <= hahmo.kartanMitat().y && minneX >= 0 && minneY >= 0) {
            if (hahmo.getKartta()[minneX][minneY] != null && !hahmo.getKartta()[minneX][minneY].ylitettava()) {

            } else if (!onkoKayty[minneX][minneY]) {
                viereiset.add(new Point(minneX, minneY));
            }
        }

        return viereiset;
    }

    /**
     * Vertaa solmun ja Hahmon koordinaatteja niin, että se saadaan muunnettua suunnaksi.
     * @param nykyinen solmu, johon Hahmon olisi tarkoitus liikkua
     * @return suunta johon hahmon olisi tarkoitus liikkua
     */
    public Suunta suunnassa(Solmu nykyinen) {
        int eroX = nykyinen.sijainti().x- hahmo.sijainti().x;
        int eroY = nykyinen.sijainti().y - hahmo.sijainti().y;
        
        if (eroX == 0 && eroY == -1) return Suunta.YLOS;
        else if (eroX == 0 && eroY == 1) return Suunta.ALAS;
        else if (eroX == 1 && eroY == 0) return Suunta.OIKEA;
        else if (eroX == -1 && eroY == 0) return Suunta.VASEN;
        return Suunta.ISTU;
    }

}
