
package thechase;

/**
 *
 * @author mcraty
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("***** The Chase *****");
        Thechase peli = new Thechase();
        peli.kaynnista();
        
        
    }
    
}
